# Sidequest

A responsive business-learning game for teen founders.

## Features
- **Sidequest Title Screen**: Interactive animated "trailer" featuring dynamic floating text badges that drift across the screen.
- **Safeguard Popup**: Popup reading `Your data is safeguarded ✔` appearing every 5 minutes.
- **Legal Pages**: Linked Privacy Policy and Terms & Conditions.
