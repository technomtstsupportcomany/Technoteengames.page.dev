document.addEventListener('DOMContentLoaded', () => {
    const titleScreen = document.getElementById('title-screen');
    const startBtn = document.getElementById('start-btn');
    const safeguardPopup = document.getElementById('safeguard-popup');
    const closePopupBtn = document.getElementById('close-popup');

    // Handle entering the website from the title screen
    if (startBtn) {
        startBtn.addEventListener('click', () => {
            if (titleScreen) {
                titleScreen.style.opacity = '0';
                titleScreen.style.transition = 'opacity 0.5s ease';
                setTimeout(() => {
                    titleScreen.style.display = 'none';
                }, 500);
            }
            // Start the 5-minute interval timer after entering the site
            startSafeguardTimer();
        });
    }

    // Close popup button action
    if (closePopupBtn) {
        closePopupBtn.addEventListener('click', () => {
            safeguardPopup.classList.add('hidden');
        });
    }

    // Function to trigger the popup every 5 minutes (300,000 ms)
    function startSafeguardTimer() {
        setInterval(() => {
            if (safeguardPopup) {
                safeguardPopup.classList.remove('hidden');
                
                // Auto-hide popup after 6 seconds
                setTimeout(() => {
                    safeguardPopup.classList.add('hidden');
                }, 6000);
            }
        }, 300000); // 5 minutes in milliseconds
    }
});
