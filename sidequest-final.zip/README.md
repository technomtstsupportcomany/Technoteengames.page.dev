# Sidequest

A responsive business-learning game for teen founders with six missions, a founder level path, a pricing planner, and a pitch builder.

## Open the site

Open `index.html` in a modern web browser. No build step, account, or internet connection is needed.

## Privacy choices

The site uses no advertising or analytics cookies. Visitors can accept persistent game-progress saving or decline and keep playing with temporary session progress. The current tab remembers the choice. The pricing planner and pitch builder do not save their entries.

## Bundle contents

- `index.html` — the home page, privacy choice panel, and playable game
- `styles.css` — responsive visual design and motion effects
- `app.js` — missions, scoring, browser storage choices, and founder tools
- `legal/terms.html` and `legal/privacy.html` — linked starter legal copy

The prototype runs as HTML, CSS, and JavaScript. Codex, Python, and C++ appear as requested project-toolkit credits. The sponsor, organization, origin, and design credits are supplied project credits; confirm permissions before public release.

The Terms and Privacy pages are starter copy, not a jurisdiction-specific legal review. Hosting configuration, audience, and future features may change applicable requirements.
